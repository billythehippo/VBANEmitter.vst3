# Welcome to VST SDK 3 base

Here you can find some helper classes useful for developing **VST 3** plug-ins.

## License & Usage guidelines

More details are found at [www.steinberg.net/sdklicenses_vst3](http://www.steinberg.net/sdklicenses_vst3)

----
Return to [VST 3 SDK](https://github.com/steinbergmedia/vst3sdk)
