# Welcome to VST 3 SDK public_sdk

Here are located:

- helper classes implementing **VST 3** Interfaces
- samples of **VST 3** Hosting and **VST 3** plug-ins
- **AAX** Wrapper
- **AU** Wrapper
- **AUv3** Wrapper
- **VST 2** Wrapper
- InterAppAudio

## License & Usage guidelines

More details are found at [VST 3 SDK public_sdk License](https://forums.steinberg.net/t/vst-3-sdk-public-sdk-license/695592)

----
Return to [VST 3 SDK](https://github.com/steinbergmedia/vst3sdk)
